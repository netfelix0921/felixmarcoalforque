# Portfolio redesign — what changed

Improved in place. Same architecture (static HTML, 4 CSS files, 3 JS files, inline
SVG sprite), same Felix AI backend contract, no new dependencies.

## Page structure

Old (9 sections): Hero → Stats → Work → About → Skills → Experience → Services → Education → Contact
New (8 sections): Hero → Stats → **What I Do** → **Featured Projects** → **Approach** → Toolkit → Experience → Contact

Page length: **8936px → 7705px** desktop, **14678px → 12303px** mobile — while the
projects section got substantially *bigger*.

## Section by section

**Hero** — New headline (`I Build Systems That / Make Businesses Better.`), new
sub, three-role badge. CTAs are now *View My Projects* (primary) and *Hire Me*
(ghost); the CV moved to a quiet text link so it stops competing. Tech strip cut
from 14 icons to 6 — the full list was duplicating the Toolkit section, and six
is the most that still fits one row at 360px.

**Stats** — "2 Companies" replaced with **ERP + IT / Business Systems**, and
"Years Experience" corrected from 2+ to **4+** (June 2022 to now). The knowledge
base now carries the same figure explicitly, in `profile.professional_experience`
and `recruiter_questions.experience_length`, so Felix AI can't contradict the
page. The existing rules against claiming specific *web-development* or *Shopify*
years are untouched — those remain undocumented.

**What I Do** — the 14-tile services wall is now 4 substantial cards. The other
real services survive as a compact tag row above the CTA, so no true capability
was deleted.

**Featured Projects** — Fintra is now a full-width case study (large preview
left, copy + three proof points + *View Project* right). MICLY, Event
Registration and Coffee POS sit in the grid below; Bollard Depot is behind
"View all projects".

**Real screenshots** — Fintra and MICLY now use actual device captures instead
of CSS miniatures (`assets/img/fintra-app-*.webp`, `micly-app-*.webp`, three
widths each, webp, 19–66KB). The phone is top-aligned and taller than its panel
so it bleeds off the bottom edge: a portrait device shown whole inside a
landscape panel has to shrink so far that nothing on screen is readable,
whereas cropping the bottom keeps the greeting, the balance and the primary
actions legible. Each panel carries a soft pool of the app's own accent colour
— violet for Fintra, pink for MICLY. On phone-width panels the device scales to
145% so it stays readable there too.

Event Registration, Coffee POS and Bollard Depot still use the CSS miniatures,
which is the honest position: those aren't live products with a URL to capture.

**Approach** (was About + the experience preamble) — the portrait figure,
schematic drawing and four pillars are gone; they explained the same idea three
times. Replaced with two paragraphs of the real Eagle Cement / Chase copy and the
**Understand → Design → Build → Automate → Improve** chain.

**Toolkit** — kept the "Honestly Listed" branding, reorganised into Frontend /
Backend & Database / Business & IT Systems / Platforms & Tools, counts retained.

**Experience** — bullets rewritten to lead with business impact rather than list
tasks. Education folded into a compact strip at the foot instead of its own
section.

**Contact** — new headline and the *Let's Talk* / *Download CV* pair.

**Felix AI** — the five suggested questions from the brief, "Portfolio
Assistant" subtitle, the verified-data disclaimer, iOS safe-area insets, and new
logic in `app.js` that tucks the launcher away (and out of the tab order) while
the contact section is on screen, so it can never sit on top of the CTAs.

**SEO** — new title/description, OG and Twitter cards, expanded `Person`
structured data, `viewport-fit=cover`, sitemap `lastmod` refreshed.

## Bugs fixed along the way

- **Project previews were being clipped at every viewport width.** The CSS mocks
  are flex items in a column, so they *shrank* when taller than their panel, and
  `overflow:hidden` on `.ui` silently cut the remainder — the bottom row of the
  Event ("QR / ID / Log") and POS ("Sales / Inventory / Reports") previews was
  sliced in half on desktop and mobile alike. Fixed with `flex: none` on the mock,
  a retuned `cqw` ramp, and flatter POS tiles (those were sized by
  `aspect-ratio`, so they never scaled with the em ramp).
- The AI launcher overlapped the contact CTAs on phones and tablets.

## Two things that need your call

1. **Event Registration and Coffee POS are still CSS miniatures.** If either
   is live somewhere you can capture, send a screenshot and it gets the same
   treatment — the pattern is now `<div class="shot shot--device shot--device-*">`
   with a single `<img class="device">` inside.

2. **React and Microsoft 365** are in the Toolkit because the brief asked for
   them, but neither is in `data/felix-knowledge-base.json`. React is defensible
   (Next.js *is* React); Microsoft 365 is your call. If you keep them, add them
   to the knowledge base so Felix AI answers consistently with the page.

## Asset housekeeping

Deleted (their markup is gone): `assets/img/fintra.png`, `assets/img/micly.png`,
`assets/img/sample1.txt`. The matching CSS miniatures for Fintra and MICLY were
removed from `components.css` too, so no dead rules ship.

Kept but now unused: `assets/img/ground-coarse.webp` and `ground-coarse-small.webp`
(116KB) — the old About-section portrait treatment. Safe to delete, or keep if
you want to restore that block.

Untouched: `fintra.png`, `micly.png`, `logo.png`, `linkedin.png`, `mail.png` and
`felixmarco.png` in the repo **root**. These were already unreferenced before
this redesign, so I left them alone in case something outside the page uses them.
